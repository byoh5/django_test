/*************************************************
   Note Name - frequency  by runcoding
   DO(C), RE(D), MI(E), PA(F), SOL(G), RA(A), SI(B) (1 ~ 8 옥타브)
 *************************************************/

#define NOTE_B0  

// 1옥타브
#define DO_1  33 // 도
#define DO_S1 35 // 도#
#define RE_1  37 // 레
#define RE_S1 39 // 레#
#define MI_1  41 // 미
#define PA_1  44 // 파
#define PA_S1 46 // 파#
#define SOL_1  49 // 솔
#define SOL_S1 52 // 솔#
#define RA_1  55 // 라
#define RA_S1 58 // 라#
#define SI_1  62 // 시

// 2옥타브
#define DO_2  65
#define DO_S2 69
#define RE_2  73
#define RE_S2 78
#define MI_2  82
#define PA_2  87
#define PA_S2 93
#define SOL_2  98
#define SOL_S2 104
#define RA_2  110
#define RA_S2 117
#define SI_2  123

// 3옥타브
#define DO_3  131
#define DO_S3 139
#define RE_3  147
#define RE_S3 156
#define MI_3  165
#define PA_3  175
#define PA_S3 185
#define SOL_3  196
#define SOL_S3 208
#define RA_3  220
#define RA_S3 233
#define SI_3  247

// 4옥타브 
#define DO_4  262
#define DO_S4 277
#define RE_4  294
#define RE_S4 311
#define MI_4  330
#define PA_4  349
#define PA_S4 370
#define SOL_4  392
#define SOL_S4 415
#define RA_4  440
#define RA_S4 466
#define SI_4  494

// 5옥타브 basic
#define DO_5  523
#define DO_S5 554
#define RE_5  587
#define RE_S5 622
#define MI_5  659
#define PA_5  698
#define PA_S5 740
#define SOL_5  784
#define SOL_S5 831
#define RA_5  880
#define RA_S5 932
#define SI_5  988

// 6옥타브
#define DO_6  1047
#define DO_S6 1109
#define RE_6  1175
#define RE_S6 1245
#define MI_6  1319
#define PA_6  1397
#define PA_S6 1480
#define SOL_6  1568
#define SOL_S6 1661
#define RA_6  1760
#define RA_S6 1865
#define SI_6  1976

// 7옥타브
#define DO_7  2093
#define DO_S7 2217
#define RE_7  2349
#define RE_S7 2489
#define MI_7  2637
#define PA_7  2794
#define PA_S7 2960
#define SOL_7  3136
#define SOL_S7 3322
#define RA_7  3520
#define RA_S7 3729
#define SI_7  3951

// 8옥타브
#define DO_8  4186
#define DO_S8 4435
#define RE_8  4699
#define RE_S8 4978

/*************************************************
   Beat    by runcoding
 *************************************************/
#define basicBeat 1000

#define beat basicBeat / 1 // 온음표(4박)
#define beat2 basicBeat/2 // 2분음표(2박)
#define beat4 basicBeat/4 // 4분음표(1박)
#define beat8 basicBeat/8 // 8분음표(0.5박)
#define beat16 basicBeat/16 // 16분음표(0.25박)

#define beat2_dot beat_2*1.5 // 점2분음표(3박)
#define beat4_dot  beat_4*1.5  // 점4분음표(1.5박)
#define beat8_dot beat_8*1.5 // 점8분음표(0.75박)
#define beat16_dot beat_16*1.5 // 점16분음표(0.375박)

/*************************************************
   servo degree    by runcoding
 *************************************************/
#define degree_do 100
#define degree_re 88
#define degree_mi 76
#define degree_pa 64
#define degree_sol 52
#define degree_ra 40
#define degree_si 28
#define degree_doo 16
#define degree_close 110
#define degree_open 0
